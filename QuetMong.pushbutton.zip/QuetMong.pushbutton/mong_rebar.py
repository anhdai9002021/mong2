# -*- coding: utf-8 -*-
"""Thep mong: bo tri theo TCVN 5574:2018 (co moc neo, dai coc thep 4 mat + dai thanh,
mong bang/dam mong tang cuong dung so do phan luc nen: tren tang cuong nhip, duoi tang cuong goi).
"""
import math
import mong_geom as G
import mong_model as M

RULES_DEFAULT = {"cover": 50.0, "clear_min": 25.0, "a_max": 250.0, "d_min": 10.0, "dai_a_max": 300.0,
                 "lot_t": 100.0, "lot_o": 100.0}
RULE_LABELS = [("cover", u"Lớp BV"), ("clear_min", u"Khe hở min"), ("a_max", u"a max"),
               ("d_min", u"Ø min"), ("dai_a_max", u"a đai max"),
               ("lot_t", u"BT lót dày"), ("lot_o", u"BT lót chìa")]

VITRI_FOOT = [
    ("DayX", u"Đáy - phương X"),
    ("DayY", u"Đáy - phương Y"),
    ("TrenX", u"Trên - phương X"),
    ("TrenY", u"Trên - phương Y"),
    ("DaiBo", u"Đai thành đài"),
]
VITRI_STRIP = [
    ("BangTren", u"Dọc trên (chủ)"),
    ("BangTrenTC", u"TC trên (nhịp)"),
    ("BangDuoi", u"Dọc dưới (chủ)"),
    ("BangDuoiTC", u"TC dưới (gối)"),
    ("BangChongPhinh", u"Chống phình"),
    ("BangDai", u"Đai gối (dày)"),
    ("BangDaiNhip", u"Đai nhịp (thưa)"),
    ("BangDaiTC", u"Đai tăng cường"),
    ("BangCanh", u"Thép cánh (MB)"),
]
STRIP_LOAI = ("MongBang", "DamMong")
BOTTOM = ("DayX", "DayY")
TOP = ("TrenX", "TrenY")

COLORS = {
    "DayX": (235, 140, 40), "DayY": (60, 180, 100),
    "TrenX": (170, 110, 220), "TrenY": (225, 100, 160),
    "DaiBo": (90, 200, 220),
    "BangDuoi": (235, 140, 40), "BangDuoiTC": (255, 190, 60),
    "BangTren": (170, 110, 220), "BangTrenTC": (225, 100, 160),
    "BangChongPhinh": (60, 180, 100),
    "BangDai": (150, 160, 175), "BangDaiNhip": (110, 130, 155), "BangDaiTC": (90, 200, 220),
    "BangCanh": (75, 165, 230),
}

QUICK_DEFAULT = {
    "don_d": 12.0, "don_a": 200.0, "don_top": False, "don_top_d": 12.0, "don_top_a": 200.0, "don_hook": True,
    "dai_d": 12.0, "dai_a": 200.0, "dai_top": True, "dai_top_d": 12.0, "dai_top_a": 200.0,
    "dai_side_on": True, "dai_side_d": 10.0, "dai_side_a": 200.0, "dai_hook": True,
    "top_n": 3, "top_d": 18.0, "top_tc_on": True, "top_tc_n": 2, "top_tc_d": 18.0,
    "bot_n": 3, "bot_d": 18.0, "bot_tc_on": True, "bot_tc_n": 2, "bot_tc_d": 18.0,
    "stir_d": 8.0, "stir_a1": 100.0, "stir_a2": 200.0,
    "stir_tc_on": True, "stir_tc_d": 8.0, "stir_tc_a": 500.0,
    "skin_on": True, "skin_n": 2, "skin_d": 12.0,
    "wing_on": True, "wing_d": 12.0, "wing_a": 200.0,
    "beam_hook": True,
}

REINFORCE_MODES = [
    ("full", u"Tăng cường đầy đủ (Trên nhịp + Dưới gối)"),
    ("top_only", u"Chỉ tăng cường lớp trên (Giữa nhịp)"),
    ("bot_only", u"Chỉ tăng cường lớp dưới (Vùng gối)"),
    ("none", u"Không tăng cường (chỉ thép chủ)"),
]


def label_of(code):
    for c, l in VITRI_FOOT + VITRI_STRIP:
        if c == code:
            return l
    return code


def code_of(label):
    for c, l in VITRI_FOOT + VITRI_STRIP:
        if l == label or c == label:
            return c
    return label


def vitri_list(loai):
    return VITRI_STRIP if loai in STRIP_LOAI else VITRI_FOOT


def kg_per_m(d):
    return d * d / 162.0


def hook_len_footing(d, H, cov):
    """Chieu dai 1 moc be vuong 90 do TCVN (mm): >= 15d, khong vuot qua H - 2*cov."""
    if d <= 0:
        return 0.0
    max_h = max(H - 2.0 * cov, 12.0 * d) if H > 0 else 20.0 * d
    return min(max(15.0 * d, 180.0), max_h)


def hook_len_beam(d, H, cov):
    """Moc neo 90 do thep doc dam vao dai/goi (mm)."""
    if d <= 0:
        return 0.0
    max_h = max(H - 2.0 * cov, 15.0 * d) if H > 0 else 25.0 * d
    return min(max(15.0 * d, 250.0), max_h)


def stirrup_hook_len(d):
    """2 moc dai 135 do TCVN: 2 * max(10d, 75mm)."""
    return 2.0 * max(10.0 * d, 75.0)


def rows_for(data, loai, ten):
    return [r for r in data.get("Thep", []) if r.get("Loai") == loai and r.get("Ten") == ten]


def set_rows(data, loai, ten, rows):
    keep = [r for r in data.get("Thep", []) if not (r.get("Loai") == loai and r.get("Ten") == ten)]
    for i, r in enumerate(rows, 1):
        r["Loai"], r["Ten"] = loai, ten
        if not r.get("STT"):
            r["STT"] = i
        keep.append(r)
    data["Thep"] = keep


def new_row(loai, ten, vitri, d=14.0, a=200.0, n=0, cover=0.0, stt=0, note=u""):
    r = M.new_record("Thep")
    r.update({"Ten": ten, "Loai": loai, "STT": stt, "ViTri": vitri, "D": d, "A": a, "SoThanh": n,
              "LopBV": cover, "GhiChu": note})
    return r


def quick_rows(loai, ten, cfg=None, mode="full"):
    c = dict(QUICK_DEFAULT)
    if cfg:
        c.update(cfg)
    if loai == "MongDon":
        hk = u"Có móc TCVN 90°" if c.get("don_hook", True) else u""
        rows = [
            new_row(loai, ten, "DayX", c["don_d"], c["don_a"], 0, stt=1, note=hk),
            new_row(loai, ten, "DayY", c["don_d"], c["don_a"], 0, stt=2, note=hk),
        ]
        if c.get("don_top"):
            rows.append(new_row(loai, ten, "TrenX", c["don_top_d"], c["don_top_a"], 0, stt=3, note=hk))
            rows.append(new_row(loai, ten, "TrenY", c["don_top_d"], c["don_top_a"], 0, stt=4, note=hk))
        return rows
    if loai == "DaiMong":
        hk = u"Thép 4 mặt + móc TCVN 90°" if c.get("dai_hook", True) else u"Thép 4 mặt"
        rows = [
            new_row(loai, ten, "DayX", c["dai_d"], c["dai_a"], 0, stt=1, note=hk),
            new_row(loai, ten, "DayY", c["dai_d"], c["dai_a"], 0, stt=2, note=hk),
        ]
        if c.get("dai_top", True):
            rows.append(new_row(loai, ten, "TrenX", c["dai_top_d"], c["dai_top_a"], 0, stt=3, note=hk))
            rows.append(new_row(loai, ten, "TrenY", c["dai_top_d"], c["dai_top_a"], 0, stt=4, note=hk))
        if c.get("dai_side_on", True):
            rows.append(new_row(loai, ten, "DaiBo", c["dai_side_d"], c["dai_side_a"], 0, stt=len(rows) + 1,
                                note=u"Đai bo thành đài (móc neo)"))
        return rows
    use_top_tc = bool(c.get("top_tc_on", True)) and mode in ("full", "top_only", "custom")
    use_bot_tc = bool(c.get("bot_tc_on", True)) and mode in ("full", "bot_only", "custom")
    if mode == "none":
        use_top_tc = False
        use_bot_tc = False
    hk_b = u"Có móc neo TCVN" if c.get("beam_hook", True) else u""
    rows = []
    stt = 1
    rows.append(new_row(loai, ten, "BangTren", c["top_d"], 0, c["top_n"], stt=stt, note=u"Lớp trên chủ · " + hk_b))
    stt += 1
    if use_top_tc and int(c.get("top_tc_n", 0)) > 0:
        rows.append(new_row(loai, ten, "BangTrenTC", c["top_tc_d"], 0, c["top_tc_n"], stt=stt, note=u"TC lớp trên giữa nhịp (0.5L)"))
        stt += 1
    rows.append(new_row(loai, ten, "BangDuoi", c["bot_d"], 0, c["bot_n"], stt=stt, note=u"Lớp dưới chủ · " + hk_b))
    stt += 1
    if use_bot_tc and int(c.get("bot_tc_n", 0)) > 0:
        rows.append(new_row(loai, ten, "BangDuoiTC", c["bot_tc_d"], 0, c["bot_tc_n"], stt=stt, note=u"TC lớp dưới vùng gối (0.5L)"))
        stt += 1
    if c.get("skin_on", True) and int(c.get("skin_n", 0)) > 0:
        rows.append(new_row(loai, ten, "BangChongPhinh", c["skin_d"], 0, c["skin_n"], stt=stt, note=u"Chống phình 2 mặt bên"))
        stt += 1
    rows.append(new_row(loai, ten, "BangDai", c["stir_d"], c["stir_a1"], 0, stt=stt, note=u"Đai gối L/4 · móc 135°"))
    stt += 1
    if float(c.get("stir_a2", 0)) > 0 and abs(float(c.get("stir_a2", 0)) - float(c.get("stir_a1", 0))) > 1e-3:
        rows.append(new_row(loai, ten, "BangDaiNhip", c["stir_d"], c["stir_a2"], 0, stt=stt, note=u"Đai nhịp L/2 · móc 135°"))
        stt += 1
    if c.get("stir_tc_on", True) and float(c.get("stir_tc_a", 0)) > 0:
        rows.append(new_row(loai, ten, "BangDaiTC", c["stir_tc_d"], c["stir_tc_a"], 0, stt=stt, note=u"Đai tăng cường · móc 135°"))
        stt += 1
    if loai == "MongBang" and c.get("wing_on", True):
        rows.append(new_row(loai, ten, "BangCanh", c["wing_d"], c["wing_a"], 0, stt=stt, note=u"Thép bản cánh · có móc 90°"))
    return rows


def default_rows(loai, ten):
    return quick_rows(loai, ten, QUICK_DEFAULT, mode="full")


def apply_quick_all(data, cfg=None, overwrite=True, loai_filter=None):
    count = 0
    targets = loai_filter or ("MongDon", "DaiMong", "MongBang", "DamMong")
    for sh in targets:
        key = "Nhom" if sh == "MongBang" else "Ten"
        seen = set()
        for r in data.get(sh, []):
            nm = r.get(key)
            if not nm or nm in seen:
                continue
            seen.add(nm)
            if not overwrite and rows_for(data, sh, nm):
                continue
            set_rows(data, sh, nm, quick_rows(sh, nm, cfg, mode="full"))
            count += 1
    return count


def apply_beams_mode(data, items, cfg=None, mode="full"):
    count = 0
    seen = set()
    for loai, ten in items:
        if loai not in STRIP_LOAI or not ten or (loai, ten) in seen:
            continue
        seen.add((loai, ten))
        set_rows(data, loai, ten, quick_rows(loai, ten, cfg, mode=mode))
        count += 1
    return count


def _frame(poly, cx, cy, th):
    c, s = math.cos(th), math.sin(th)
    loc = [((x - cx) * c + (y - cy) * s, -(x - cx) * s + (y - cy) * c) for x, y in poly]
    us = [p[0] for p in loc] or [0.0]
    vs = [p[1] for p in loc] or [0.0]
    return {"cx": cx, "cy": cy, "c": c, "s": s, "poly": loc, "umin": min(us), "umax": max(us),
            "vmin": min(vs), "vmax": max(vs)}


def frame_footing(rec):
    return _frame(M.str_to_poly(rec.get("BienDang")), M.to_float(rec.get("TamX")), M.to_float(rec.get("TamY")),
                  math.radians(M.to_float(rec.get("Goc"))))


def frame_strip(rec):
    x1, y1 = M.to_float(rec.get("X1")), M.to_float(rec.get("Y1"))
    x2, y2 = M.to_float(rec.get("X2")), M.to_float(rec.get("Y2"))
    return _frame(M.str_to_poly(rec.get("BienDang")), (x1 + x2) / 2.0, (y1 + y2) / 2.0,
                  math.atan2(y2 - y1, x2 - x1))


def to_local(fr, p):
    dx, dy = p[0] - fr["cx"], p[1] - fr["cy"]
    return (dx * fr["c"] + dy * fr["s"], -dx * fr["s"] + dy * fr["c"])


def to_global(fr, p):
    return (fr["cx"] + p[0] * fr["c"] - p[1] * fr["s"], fr["cy"] + p[0] * fr["s"] + p[1] * fr["c"])


def clip_intervals(poly, axis, c):
    pts = poly if axis == "u" else [(p[1], p[0]) for p in poly]
    c = c + 1e-6
    xs = []
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        if (y1 > c) != (y2 > c):
            xs.append(x1 + (c - y1) * (x2 - x1) / (y2 - y1))
    xs.sort()
    return [(xs[i], xs[i + 1]) for i in range(0, len(xs) - 1, 2)]


def row_cover(r, rules):
    c = M.to_float(r.get("LopBV"))
    return c if c > 0 else rules["cover"]


def bar_layout(fr, r, rules):
    vt = r.get("ViTri")
    d, a = M.to_float(r.get("D")), M.to_float(r.get("A"))
    cov = row_cover(r, rules)
    if vt in ("DayX", "TrenX"):
        run, lo, hi = "u", fr["vmin"], fr["vmax"]
    elif vt in ("DayY", "TrenY"):
        run, lo, hi = "v", fr["umin"], fr["umax"]
    else:
        return None
    out = {"run": run, "pos": [], "lines": [], "n": 0}
    if d <= 0 or a <= 0:
        return out
    span = (hi - lo) - 2 * cov - d
    if span < 0:
        return out
    n = int(span / a + 1e-9) + 1
    mid = (lo + hi) / 2.0
    start = mid - (n - 1) * a / 2.0
    for i in range(n):
        p = start + i * a
        out["pos"].append(p)
        for t0, t1 in clip_intervals(fr["poly"], run, p):
            t0 += cov
            t1 -= cov
            if t1 - t0 > 1.0:
                out["lines"].append((run, p, t0, t1))
    out["n"] = len(out["lines"])
    return out


def layer_z(rows, H, rules):
    z = {}
    bot = sorted([r for r in rows if r.get("ViTri") in BOTTOM], key=lambda r: M.to_float(r.get("STT")))
    top = sorted([r for r in rows if r.get("ViTri") in TOP], key=lambda r: M.to_float(r.get("STT")))
    acc = row_cover(bot[0], rules) if bot else 0.0
    for r in bot:
        d = M.to_float(r.get("D"))
        z[r.get("ViTri")] = acc + d / 2.0
        acc += d
    acc = H - (row_cover(top[0], rules) if top else 0.0)
    for r in top:
        d = M.to_float(r.get("D"))
        z[r.get("ViTri")] = acc - d / 2.0
        acc -= d
    return z


def footing_stats(fr, rows, rules, H=500.0):
    out, tot = [], 0.0
    B_est = max(fr["umax"] - fr["umin"], 0.0)
    L_est = max(fr["vmax"] - fr["vmin"], 0.0)
    for r in sorted(rows, key=lambda r: M.to_float(r.get("STT"))):
        vt = r.get("ViTri")
        d = M.to_float(r.get("D"))
        a = M.to_float(r.get("A"))
        cov = row_cover(r, rules)
        if vt == "DaiBo":
            z_span = max(H - 2.0 * cov - 100.0, 0.0)
            n_rings = max(1, int(z_span / a) + 1) if a > 0 else 0
            perim = 2.0 * (max(B_est - 2.0 * cov, 0.0) + max(L_est - 2.0 * cov, 0.0)) + stirrup_hook_len(d)
            L = n_rings * perim
            kg = L / 1000.0 * kg_per_m(d)
            tot += kg
            out.append((u"T%d  Ø%.0f a%.0f (đai đài)" % (M.to_float(r.get("STT")), d, a), n_rings, L / 1000.0, kg))
            continue
        bl = bar_layout(fr, r, rules)
        if bl is None:
            continue
        hk = 2.0 * hook_len_footing(d, H, cov)
        L = sum((t1 - t0) + hk for _, _, t0, t1 in bl["lines"])
        kg = L / 1000.0 * kg_per_m(d)
        tot += kg
        out.append((u"T%d  Ø%.0f a%.0f (+móc)" % (M.to_float(r.get("STT")), d, a),
                    bl["n"], L / 1000.0, kg))
    return out, tot


def section_footing(fr, rows, H, rules, cut_axis, pos):
    horiz = "v" if cut_axis == "u" else "u"
    sec = {"intervals": clip_intervals(fr["poly"], horiz, pos), "dots": [], "hlines": [], "horiz": horiz, "side_dots": []}
    zs = layer_z(rows, H, rules)
    for r in rows:
        vt = r.get("ViTri")
        if vt == "DaiBo":
            d, a = M.to_float(r.get("D")), M.to_float(r.get("A"))
            cov = row_cover(r, rules)
            if d > 0 and a > 0 and sec["intervals"]:
                h0 = min(x[0] for x in sec["intervals"]) + cov + d / 2.0
                h1 = max(x[1] for x in sec["intervals"]) - cov - d / 2.0
                z0, z1 = cov + 80.0, H - cov - 80.0
                if z1 >= z0:
                    cnt = max(1, int((z1 - z0) / a) + 1)
                    for k in range(cnt):
                        zz = (z0 + z1) / 2.0 if cnt == 1 else z0 + (z1 - z0) * k / float(cnt - 1)
                        sec["dots"].append((h0, zz, d, vt))
                        sec["dots"].append((h1, zz, d, vt))
            continue
        bl = bar_layout(fr, r, rules)
        if bl is None or not bl["lines"] or vt not in zs:
            continue
        d = M.to_float(r.get("D"))
        z = zs[vt]
        if bl["run"] == cut_axis:
            for run, p, t0, t1 in bl["lines"]:
                if t0 <= pos <= t1:
                    sec["dots"].append((p, z, d, vt))
        else:
            h0 = min(t0 for _, _, t0, _ in bl["lines"])
            h1 = max(t1 for _, _, _, t1 in bl["lines"])
            sec["hlines"].append((h0, h1, z, d, vt, r))
    return sec


def _row_by(rows, vt):
    for r in rows:
        if r.get("ViTri") == vt:
            return r
    return None


def strip_section(rec, rows, rules):
    fr = frame_strip(rec)
    b = M.to_float(rec.get("B"))
    if b > 0 and M.to_float(rec.get("Dai")) > 0:
        off = M.to_float(rec.get("LechTam"))
        vmin, vmax = off - b / 2.0, off + b / 2.0
    else:
        vmin, vmax = fr["vmin"], fr["vmax"]
        b = vmax - vmin
    H = M.to_float(rec.get("H"))
    sec = {"b": b, "H": H, "vmin": vmin, "vmax": vmax, "dots": [], "stirrup": None, "wing_bar": None}
    dai = [r for r in rows if r.get("ViTri") == "BangDai"]
    dd = M.to_float(dai[0].get("D")) if dai else 0.0
    cov_d = row_cover(dai[0], rules) if dai else rules["cover"]
    if dai:
        sec["stirrup"] = (vmin + cov_d, cov_d, vmax - cov_d, H - cov_d, dd)
    r_bot = _row_by(rows, "BangDuoi")
    r_top = _row_by(rows, "BangTren")
    d_bot = M.to_float(r_bot.get("D")) if r_bot else 0.0
    d_top = M.to_float(r_top.get("D")) if r_top else 0.0
    for r in rows:
        vt = r.get("ViTri")
        if vt in ("BangDuoi", "BangTren", "BangDuoiTC", "BangTrenTC"):
            d, n = M.to_float(r.get("D")), int(M.to_float(r.get("SoThanh")))
            cov = row_cover(r, rules)
            if d <= 0 or n <= 0:
                continue
            x0 = vmin + cov + dd + d / 2.0
            x1 = vmax - cov - dd - d / 2.0
            if vt == "BangDuoi":
                z = cov + dd + d / 2.0
            elif vt == "BangDuoiTC":
                gap = max(rules["clear_min"], d_bot, d)
                z = cov + dd + d_bot + gap + d / 2.0
            elif vt == "BangTren":
                z = H - cov - dd - d / 2.0
            else:
                gap = max(rules["clear_min"], d_top, d)
                z = H - cov - dd - d_top - gap - d / 2.0
            for i in range(n):
                x = (x0 + x1) / 2.0 if n == 1 else x0 + (x1 - x0) * i / (n - 1.0)
                sec["dots"].append((x, z, d, vt))
        elif vt == "BangChongPhinh":
            d, n = M.to_float(r.get("D")), int(M.to_float(r.get("SoThanh")))
            cov = row_cover(r, rules)
            if d <= 0 or n <= 0:
                continue
            pairs = max(1, (n + 1) // 2)
            for k in range(pairs):
                z = H * (k + 1) / float(pairs + 1)
                sec["dots"].append((vmin + cov + dd + d / 2.0, z, d, vt))
                if n > 1:
                    sec["dots"].append((vmax - cov - dd - d / 2.0, z, d, vt))
        elif vt == "BangCanh":
            d = M.to_float(r.get("D"))
            cov = row_cover(r, rules)
            if d > 0:
                sec["wing_bar"] = (vmin + cov, cov + d / 2.0, vmax - cov, d)
    return sec


def strip_stats(rec, rows, rules):
    Ls = M.to_float(rec.get("Dai"))
    b, H = M.to_float(rec.get("B")), M.to_float(rec.get("H"))
    has_nhip = any(r.get("ViTri") == "BangDaiNhip" for r in rows)
    out, tot = [], 0.0
    for r in sorted(rows, key=lambda r: M.to_float(r.get("STT"))):
        vt = r.get("ViTri")
        d = M.to_float(r.get("D"))
        a = M.to_float(r.get("A"))
        cov = row_cover(r, rules)
        if vt in ("BangDuoi", "BangTren"):
            n = int(M.to_float(r.get("SoThanh")))
            L = n * (Ls + 2.0 * hook_len_beam(d, H, cov))
            cnt = n
            lab = u"T%d  %dØ%.0f (+móc)" % (M.to_float(r.get("STT")), n, d)
        elif vt == "BangChongPhinh":
            n = int(M.to_float(r.get("SoThanh")))
            L = n * (Ls + 2.0 * hook_len_beam(d, H, cov))
            cnt = n
            lab = u"T%d  %dØ%.0f" % (M.to_float(r.get("STT")), n, d)
        elif vt == "BangTrenTC":
            n = int(M.to_float(r.get("SoThanh")))
            L = n * (0.5 * Ls)
            cnt = n
            lab = u"T%d  %dØ%.0f (TC nhịp)" % (M.to_float(r.get("STT")), n, d)
        elif vt == "BangDuoiTC":
            n = int(M.to_float(r.get("SoThanh")))
            L = n * (0.5 * Ls + 2.0 * hook_len_beam(d, H, cov))
            cnt = n
            lab = u"T%d  %dØ%.0f (TC gối)" % (M.to_float(r.get("STT")), n, d)
        elif vt == "BangDai":
            zone = 0.5 * Ls if has_nhip else Ls
            cnt = int(zone / a) + 1 if a > 0 else 0
            L = cnt * (2.0 * (max(b - 2 * cov, 0.0) + max(H - 2 * cov, 0.0)) + stirrup_hook_len(d))
            lab = u"T%d  Ø%.0f a%.0f" % (M.to_float(r.get("STT")), d, a)
        elif vt == "BangDaiNhip":
            cnt = int((0.5 * Ls) / a) + 1 if a > 0 else 0
            L = cnt * (2.0 * (max(b - 2 * cov, 0.0) + max(H - 2 * cov, 0.0)) + stirrup_hook_len(d))
            lab = u"T%d  Ø%.0f a%.0f (nhịp)" % (M.to_float(r.get("STT")), d, a)
        elif vt == "BangDaiTC":
            cnt = int(Ls / a) + 1 if a > 0 else 0
            L = cnt * (2.0 * (max(b - 2 * cov, 0.0) + max(H - 2 * cov, 0.0)) + stirrup_hook_len(d))
            lab = u"T%d  Ø%.0f a%.0f (đai TC)" % (M.to_float(r.get("STT")), d, a)
        elif vt == "BangCanh":
            cnt = int(Ls / a) + 1 if a > 0 else 0
            L = cnt * (max(b - 2 * cov, 0.0) + 2.0 * hook_len_footing(d, H * 0.4, cov))
            lab = u"T%d  Ø%.0f a%.0f (cánh+móc)" % (M.to_float(r.get("STT")), d, a)
        else:
            continue
        kg = L / 1000.0 * kg_per_m(d)
        tot += kg
        out.append((lab, cnt, L / 1000.0, kg))
    return out, tot


def _check_common(r, rules, msgs):
    d = M.to_float(r.get("D"))
    lab = u"T%d" % M.to_float(r.get("STT"))
    if d <= 0:
        msgs.append(u"%s: thiếu đường kính" % lab)
        return False
    if d < rules["d_min"] and r.get("ViTri") not in ("BangDai", "BangDaiNhip", "BangDaiTC"):
        msgs.append(u"%s: Ø%.0f nhỏ hơn Ø min %.0f" % (lab, d, rules["d_min"]))
    return True


def check_footing(rec, rows, rules):
    msgs = []
    if not rows:
        return [u"Chưa nhập thép"]
    fr = frame_footing(rec)
    H = M.to_float(rec.get("H"))
    seen = {}
    for r in rows:
        vt = r.get("ViTri")
        lab = u"T%d" % M.to_float(r.get("STT"))
        seen[vt] = seen.get(vt, 0) + 1
        if vt not in dict(VITRI_FOOT):
            msgs.append(u"%s: vị trí không hợp lệ" % lab)
            continue
        if not _check_common(r, rules, msgs):
            continue
        d, a = M.to_float(r.get("D")), M.to_float(r.get("A"))
        if a <= 0:
            msgs.append(u"%s: thiếu khoảng cách a" % lab)
            continue
        if vt != "DaiBo" and a > rules["a_max"]:
            msgs.append(u"%s: a=%.0f lớn hơn a max %.0f" % (lab, a, rules["a_max"]))
        if vt != "DaiBo":
            need = max(d, rules["clear_min"])
            if a - d < need - 1e-6:
                msgs.append(u"%s: khe hở %.0f nhỏ hơn %.0f (Ø%.0f a%.0f)" % (lab, a - d, need, d, a))
            bl = bar_layout(fr, r, rules)
            if bl is None or bl["n"] < 2:
                msgs.append(u"%s: không bố trí được thép trong biên móng" % lab)
    for vt, n in seen.items():
        if n > 1:
            msgs.append(u"Trùng vị trí thép: %s" % label_of(vt))
    if M.to_float(rec.get("SoCoc")) > 0:
        for req in ("DayX", "DayY", "TrenX", "TrenY"):
            if req not in seen:
                msgs.append(u"Đài cọc thiếu %s (cần đủ thép 4 mặt)" % label_of(req))
    ds = sum(M.to_float(r.get("D")) for r in rows if r.get("ViTri") in BOTTOM + TOP)
    cov = max([row_cover(r, rules) for r in rows] + [rules["cover"]])
    if H > 0 and 2 * cov + ds > H:
        msgs.append(u"Chiều cao móng H=%.0f không đủ chứa các lớp thép" % H)
    return msgs


def check_strip(rec, rows, rules):
    msgs = []
    if not rows:
        return [u"Chưa nhập thép"]
    b, H = M.to_float(rec.get("B")), M.to_float(rec.get("H"))
    dai = [r for r in rows if r.get("ViTri") in ("BangDai", "BangDaiNhip")]
    dd = M.to_float(dai[0].get("D")) if dai else 0.0
    if not dai:
        msgs.append(u"Thiếu thép đai")
    for r in dai:
        d_ = M.to_float(r.get("D"))
        a = M.to_float(r.get("A"))
        if d_ < 6:
            msgs.append(u"Đai Ø%.0f nhỏ hơn Ø6" % d_)
        if a <= 0:
            msgs.append(u"%s: thiếu khoảng cách a" % label_of(r.get("ViTri")))
        elif a > rules["dai_a_max"]:
            msgs.append(u"%s: a=%.0f lớn hơn a đai max %.0f" % (label_of(r.get("ViTri")), a, rules["dai_a_max"]))
    for r in [x for x in rows if x.get("ViTri") == "BangDaiTC"]:
        if M.to_float(r.get("D")) < 6:
            msgs.append(u"Đai tăng cường Ø%.0f nhỏ hơn Ø6" % M.to_float(r.get("D")))
        if M.to_float(r.get("A")) <= 0:
            msgs.append(u"Đai tăng cường: thiếu khoảng cách a")
    for vt in ("BangDuoi", "BangTren"):
        sel = [r for r in rows if r.get("ViTri") == vt]
        if not sel:
            msgs.append(u"Thiếu thép %s" % label_of(vt))
            continue
        for r in sel:
            if not _check_common(r, rules, msgs):
                continue
            d, n = M.to_float(r.get("D")), int(M.to_float(r.get("SoThanh")))
            cov = row_cover(r, rules)
            if n < 2:
                msgs.append(u"%s: cần tối thiểu 2 thanh" % label_of(vt))
                continue
            avail = b - 2 * cov - 2 * dd - d
            pitch = avail / (n - 1.0)
            need = max(d, rules["clear_min"])
            if avail <= 0 or pitch - d < need - 1e-6:
                msgs.append(u"%s: khe hở %.0f nhỏ hơn %.0f (%d Ø%.0f trong b=%.0f)" % (label_of(vt), pitch - d, need, n, d, b))
    for vt in ("BangDuoiTC", "BangTrenTC", "BangChongPhinh"):
        for r in [x for x in rows if x.get("ViTri") == vt]:
            if _check_common(r, rules, msgs) and int(M.to_float(r.get("SoThanh"))) < 1:
                msgs.append(u"%s: số thanh phải >= 1" % label_of(vt))
    for r in [x for x in rows if x.get("ViTri") == "BangCanh"]:
        if _check_common(r, rules, msgs):
            a = M.to_float(r.get("A"))
            if a <= 0 or a > rules["a_max"]:
                msgs.append(u"Thép cánh: a=%.0f không hợp lệ (1..%.0f)" % (a, rules["a_max"]))
    if H > 700.0 and not any(r.get("ViTri") == "BangChongPhinh" for r in rows):
        msgs.append(u"H=%.0f > 700 mm: nên bố trí thép chống phình (2Ø12)" % H)
    ds = sum(M.to_float(r.get("D")) for r in rows if r.get("ViTri") in ("BangDuoi", "BangTren"))
    cov = rules["cover"]
    if H > 0 and 2 * (cov + dd) + ds > H:
        msgs.append(u"Chiều cao băng/dầm H=%.0f không đủ chứa thép" % H)
    return msgs


def check_all(data, rules):
    out = []
    seen = set()
    for sh in ("MongDon", "DaiMong"):
        for i, rec in enumerate(data.get(sh, [])):
            if not M.to_flag(rec.get("Chon")) or (sh, rec.get("Ten")) in seen:
                continue
            seen.add((sh, rec.get("Ten")))
            for m in check_footing(rec, rows_for(data, sh, rec.get("Ten")), rules):
                out.append((sh, i, u"%s" % rec.get("Ten"), u"Thép: " + m))
    for i, rec in enumerate(data.get("MongBang", [])):
        if not M.to_flag(rec.get("Chon")) or ("MongBang", rec.get("Nhom")) in seen:
            continue
        seen.add(("MongBang", rec.get("Nhom")))
        for m in check_strip(rec, rows_for(data, "MongBang", rec.get("Nhom")), rules):
            out.append(("MongBang", i, u"%s" % rec.get("Nhom"), u"Thép: " + m))
    for i, rec in enumerate(data.get("DamMong", [])):
        if not M.to_flag(rec.get("Chon")) or ("DamMong", rec.get("Ten")) in seen:
            continue
        seen.add(("DamMong", rec.get("Ten")))
        for m in check_strip(rec, rows_for(data, "DamMong", rec.get("Ten")), rules):
            out.append(("DamMong", i, u"%s" % rec.get("Ten"), u"Thép: " + m))
    return out


def _end_pts(s):
    return ((M.to_float(s.get("X1")), M.to_float(s.get("Y1"))), (M.to_float(s.get("X2")), M.to_float(s.get("Y2"))))


def chain_segments(segs, rec, tol=60.0):
    def dist(a, b):
        return math.hypot(a[0] - b[0], a[1] - b[1])
    s0, e0 = _end_pts(rec)
    d0 = (e0[0] - s0[0], e0[1] - s0[1])
    l0 = math.hypot(d0[0], d0[1])
    chain, start, end = [rec], s0, e0
    rest = [s for s in segs if s is not rec]
    changed = True
    while changed and rest:
        changed = False
        for s in list(rest):
            ps, pe = _end_pts(s)
            ds = (pe[0] - ps[0], pe[1] - ps[1])
            ls = math.hypot(ds[0], ds[1])
            if l0 > 1e-6 and ls > 1e-6 and abs(d0[0] * ds[1] - d0[1] * ds[0]) / (l0 * ls) > 0.035:
                continue
            if dist(ps, end) <= tol:
                chain.append(s)
                end = pe
            elif dist(pe, end) <= tol:
                chain.append(s)
                end = ps
            elif dist(pe, start) <= tol:
                chain.insert(0, s)
                start = ps
            elif dist(ps, start) <= tol:
                chain.insert(0, s)
                start = pe
            else:
                continue
            rest.remove(s)
            changed = True
    return chain, start, end


def frame_chain(chain, start, end):
    pts = []
    for s in chain:
        pts.extend(M.str_to_poly(s.get("BienDang")))
    return _frame(pts, (start[0] + end[0]) / 2.0, (start[1] + end[1]) / 2.0,
                  math.atan2(end[1] - start[1], end[0] - start[0]))


def local_extent(fr, poly):
    loc = [to_local(fr, p) for p in poly]
    if not loc:
        return (0.0, 0.0, 0.0, 0.0)
    us = [p[0] for p in loc]
    vs = [p[1] for p in loc]
    return (min(us), max(us), min(vs), max(vs))


def centre_intervals(fr, poly):
    return clip_intervals([to_local(fr, p) for p in poly], "u", 0.0)


def stub_pieces(fpoly, beam, cut):
    fb = frame_strip(beam)
    u0, u1, v0, v1 = fb["umin"], fb["umax"], fb["vmin"], fb["vmax"]
    fl = [to_local(fb, p) for p in fpoly]
    iv = [(a, b) for a, b in clip_intervals(fl, "u", 0.0) if b > u0 and a < u1]
    if not iv:
        us = [p[0] for p in fl]
        if not us or max(min(us) - u1, u0 - max(us), 0.0) > 200.0:
            return []
        iv = [(min(us), max(us))]
    fa = min(a for a, b in iv)
    fz = max(b for a, b in iv)
    out = []
    x1 = min(fa, u1)
    if x1 - u0 > 1.0:
        x0 = max(u0, x1 - cut)
        out.append({"frame": fb, "x0": x0, "x1": x1, "v0": v0, "v1": v1, "zig0": x0 > u0 + 1.0, "zig1": False})
    x0 = max(fz, u0)
    if u1 - x0 > 1.0:
        x1 = min(u1, x0 + cut)
        out.append({"frame": fb, "x0": x0, "x1": x1, "v0": v0, "v1": v1, "zig0": False, "zig1": x1 < u1 - 1.0})
    return out


def piece_polygon(pc, amp):
    x0, x1, v0, v1 = pc["x0"], pc["x1"], pc["v0"], pc["v1"]
    n = 6
    vs = [v0 + (v1 - v0) * i / float(n) for i in range(n + 1)]
    def edge(x, zig):
        if not zig:
            return [(x, v0), (x, v1)]
        return [(x + (0.0 if i in (0, n) else (amp if i % 2 else -amp)), vs[i]) for i in range(n + 1)]
    pts = edge(x0, pc["zig0"]) + list(reversed(edge(x1, pc["zig1"])))
    return [to_global(pc["frame"], p) for p in pts]


def pile_embed(pile, rec):
    return min(M.to_float(pile.get("ZDinh")) - M.to_float(rec.get("ZDay")), M.to_float(rec.get("H")))
