#! python3
# -*- coding: utf-8 -*-
"""XCTX - Quet Mong (buoc 1): quet mong don / dai coc / mong bang theo Level -> Excel -> xem, kiem tra."""
import os
import sys
import json
import traceback

try:
    _HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:
    _HERE = os.getcwd()
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")
clr.AddReference("System.Windows.Forms")

# pyRevit CPython giu module trong bo nho suot phien Revit -> xoa cache de luon chay ma moi nhat
for _m in ("mong_geom", "xlsxio", "mong_model", "mong_scan", "mong_ui", "mong_rebar", "mong_review"):
    sys.modules.pop(_m, None)

import mong_scan as S
import mong_model as M
import mong_ui as UI
import mong_review as RV
import mong_rebar as RB

uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document

SETTINGS = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "XCTX", "mong_thep.json")


def load_settings():
    try:
        with open(SETTINGS, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(d):
    try:
        os.makedirs(os.path.dirname(SETTINGS), exist_ok=True)
        with open(SETTINGS, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def default_excel():
    p = doc.PathName
    if p:
        base = os.path.splitext(os.path.basename(p))[0]
        return os.path.join(os.path.dirname(p), base + "_Mong.xlsx")
    return os.path.join(os.path.expanduser("~"), "Desktop", "Mong.xlsx")


def main():
    st = load_settings()
    levels = S.get_levels(doc)
    if not levels:
        UI.msg(u"Model chưa có Level nào.")
        return
    fam_map = S.list_families(doc)
    fams = sorted([(k, v[0], v[2]) for k, v in fam_map.items()], key=lambda t: t[0].lower())
    dai_fams = S.list_foundation_families(doc)

    def get_params(fam_name):
        el = fam_map[fam_name][1]
        return S.list_numeric_params(el)

    # nho lua chon coc / Level lan truoc
    pile_saved = dict(st.get("pile") or {})
    pile_saved["shared"] = st.get("shared", False)
    if pile_saved.get("dai_fams") is None:      # lan dau: tu tick family co ten dang "dai coc / pile cap"
        pile_saved["dai_fams"] = [n for n, _ in dai_fams if S.guess_dai(n)]
    default_path = st.get("excel") or default_excel()
    if st.get("excel") and doc.PathName and os.path.dirname(st["excel"]) != os.path.dirname(doc.PathName):
        default_path = default_excel()

    dlg = UI.ScanDialog([S.level_label(l) for l in levels], fams, get_params,
                        {"families": pile_saved.get("families"), "d_param": pile_saved.get("d_param"),
                         "l_param": pile_saved.get("l_param"), "shape": pile_saved.get("shape"),
                         "shared": pile_saved.get("shared"), "bang_b": st.get("bang_b", 800),
                         "dai_fams": pile_saved.get("dai_fams")},
                        default_path, dark=st.get("dark", True), dai_families=dai_fams)
    res = dlg.show()
    if not res:
        return

    chosen = [levels[i] for i in res["levels"]]
    st.update({"pile": res["pile"], "shared": res["shared"], "excel": res["path"], "dark": res["dark"],
               "bang_b": res["bang_b"]})
    save_settings(st)

    UI.Cursor.Current = UI.Cursors.WaitCursor
    try:
        data, info, notes = S.scan(doc, chosen, res["pile"], res["shared"], res["bang_b"])
    finally:
        UI.Cursor.Current = UI.Cursors.Default

    # giu lai thep da nhap trong file Excel cu (khop theo loai + ten mong)
    data.setdefault("Thep", [])
    if os.path.exists(res["path"]):
        try:
            old, old_info = M.load_model(res["path"])
            names = set([("MongDon", r["Ten"]) for r in data["MongDon"]] + [("DaiMong", r["Ten"]) for r in data["DaiMong"]]
                        + [("MongBang", r["Nhom"]) for r in data["MongBang"]]
                        + [("DamMong", r["Ten"]) for r in data["DamMong"]])
            data["Thep"] = [t for t in old.get("Thep", []) if (t.get("Loai"), t.get("Ten")) in names]
            for k, v in old_info.items():
                if k.startswith(u"QD "):
                    info[k] = v
        except Exception:
            pass

    M.run_checks(data)
    try:
        M.save_model(res["path"], data, info)
    except Exception as ex:
        UI.msg(u"Quét xong nhưng chưa ghi được Excel (file đang mở?).\nBạn vẫn xem được trong form và bấm Lưu Excel sau.\n\n%s" % ex,
               icon=UI.MessageBoxIcon.Warning)

    if notes:
        UI.msg(u"Lưu ý khi quét:\n\n" + u"\n".join(notes[:25]))
    RV.ReviewForm(data, info, res["path"], dark=res["dark"]).show()


try:
    main()
except Exception:
    UI.msg(u"Lỗi:\n\n" + traceback.format_exc(), icon=UI.MessageBoxIcon.Error)
