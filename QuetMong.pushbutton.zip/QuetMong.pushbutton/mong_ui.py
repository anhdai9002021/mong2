# -*- coding: utf-8 -*-
"""Giao dien WinForms (CPython 3): hop thoai chon Level/coc va form xem - kiem tra Excel."""
import os
import clr

clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
import System
from System import Array, Object
from System.Drawing import Color, Font, FontStyle, Point, PointF, Size, Pen, SolidBrush
from System.Drawing.Drawing2D import SmoothingMode
from System.Reflection import BindingFlags
from System.Windows.Forms import (
    Application, Form, Panel, Label, Button, TextBox, ComboBox, ComboBoxStyle, CheckedListBox,
    CheckBox, TabControl, TabPage, DataGridView, DataGridViewTextBoxColumn,
    DataGridViewCheckBoxColumn, DataGridViewColumnSortMode, DataGridViewSelectionMode,
    DataGridViewAutoSizeColumnsMode, DockStyle, FormStartPosition, FlatStyle, SplitContainer,
    ListBox, MessageBox, MessageBoxButtons, MessageBoxIcon, SaveFileDialog, DialogResult,
    BorderStyle, Cursor, Cursors, FormBorderStyle)

import mong_model as M
import mong_geom as G

try:
    Application.EnableVisualStyles()
except Exception:
    pass

FONT = "Segoe UI"


def _rgb(r, g, b):
    return Color.FromArgb(r, g, b)


DARK = {"bg": _rgb(30, 31, 36), "panel": _rgb(40, 42, 50), "fg": _rgb(228, 230, 236),
        "accent": _rgb(0, 122, 204), "grid": _rgb(34, 36, 43), "alt": _rgb(42, 44, 52),
        "line": _rgb(72, 76, 88), "warn": _rgb(104, 70, 30), "sel": _rgb(0, 96, 168),
        "pv_bg": _rgb(24, 25, 30), "main": _rgb(70, 150, 220), "main_fill": _rgb(36, 70, 104),
        "col": _rgb(235, 110, 90), "pile": _rgb(120, 210, 140), "hl": _rgb(255, 205, 80),
        "dim": _rgb(150, 154, 168)}
LIGHT = {"bg": _rgb(243, 244, 247), "panel": _rgb(255, 255, 255), "fg": _rgb(30, 32, 38),
         "accent": _rgb(0, 102, 184), "grid": _rgb(255, 255, 255), "alt": _rgb(244, 247, 251),
         "line": _rgb(200, 205, 214), "warn": _rgb(255, 232, 190), "sel": _rgb(176, 214, 246),
         "pv_bg": _rgb(252, 252, 253), "main": _rgb(20, 90, 170), "main_fill": _rgb(214, 232, 250),
         "col": _rgb(200, 60, 40), "pile": _rgb(30, 140, 70), "hl": _rgb(230, 140, 0),
         "dim": _rgb(110, 116, 130)}


def msg(text, title=u"Quét Móng", icon=MessageBoxIcon.Information):
    MessageBox.Show(text, title, MessageBoxButtons.OK, icon)


def ask_yes_no(text, title=u"Quét Móng"):
    return MessageBox.Show(text, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes


def apply_theme(ctrl, th):
    n = ctrl.GetType().Name
    if n == "DataGridView":
        ctrl.BackgroundColor = th["grid"]
        ctrl.GridColor = th["line"]
        ctrl.EnableHeadersVisualStyles = False
        hs = ctrl.ColumnHeadersDefaultCellStyle
        hs.BackColor = th["panel"]
        hs.ForeColor = th["fg"]
        hs.SelectionBackColor = th["panel"]
        hs.SelectionForeColor = th["fg"]
        ds = ctrl.DefaultCellStyle
        ds.BackColor = th["grid"]
        ds.ForeColor = th["fg"]
        ds.SelectionBackColor = th["sel"]
        ds.SelectionForeColor = th["fg"]
        ctrl.AlternatingRowsDefaultCellStyle.BackColor = th["alt"]
    elif n == "Button":
        ctrl.FlatStyle = FlatStyle.Flat
        ctrl.FlatAppearance.BorderColor = th["line"]
        ctrl.BackColor = th["panel"]
        ctrl.ForeColor = th["fg"]
    elif n in ("TextBox", "ComboBox", "CheckedListBox", "ListBox", "TreeView"):
        ctrl.BackColor = th["panel"]
        ctrl.ForeColor = th["fg"]
    elif n == "TabControl":
        ctrl.BackColor = th["bg"]
        ctrl.ForeColor = th["fg"]
    else:
        ctrl.BackColor = th["bg"]
        ctrl.ForeColor = th["fg"]
    try:
        for c in ctrl.Controls:
            apply_theme(c, th)
    except Exception:
        pass


def _label(text, x, y, w=300, h=20, bold=False):
    lb = Label()
    lb.Text = text
    lb.Location = Point(x, y)
    lb.Size = Size(w, h)
    lb.Font = Font(FONT, 9.0, FontStyle.Bold if bold else FontStyle.Regular)
    return lb


def _button(text, x, y, w=110, h=30):
    b = Button()
    b.Text = text
    b.Location = Point(x, y)
    b.Size = Size(w, h)
    b.Font = Font(FONT, 9.0)
    return b


# ===================================================================== hop thoai quet
class ScanDialog(object):
    NONE_TXT = u"(Lấy từ hình khối)"

    def __init__(self, level_labels, families, get_params, settings, default_path, dark=True, dai_families=None):
        self.families = families            # list[(ten, so_luong, category)]
        self.dai_families = dai_families or []   # list[(ten, so_luong)] Structural Foundation
        self.get_params = get_params
        self.settings = settings or {}
        self.result = None
        self.dark = dark
        f = Form()
        f.Text = u"XCTX - Quét móng theo Level"
        f.Size = Size(900, 700)
        f.StartPosition = FormStartPosition.CenterScreen
        f.FormBorderStyle = FormBorderStyle.FixedDialog
        f.MaximizeBox = False
        f.MinimizeBox = False
        f.Font = Font(FONT, 9.0)
        self.f = f

        f.Controls.Add(_label(u"1. Chọn Level có móng cần quét", 16, 12, 360, bold=True))
        self.clb_lv = CheckedListBox()
        self.clb_lv.Location = Point(16, 36)
        self.clb_lv.Size = Size(360, 200)
        self.clb_lv.CheckOnClick = True
        self.clb_lv.BorderStyle = BorderStyle.FixedSingle
        for t in level_labels:
            self.clb_lv.Items.Add(t)
        f.Controls.Add(self.clb_lv)

        f.Controls.Add(_label(u"3. Gốc toạ độ (khớp với file CAD xuất từ Revit)", 16, 250, 400, bold=True))
        self.cb_coord = ComboBox()
        self.cb_coord.DropDownStyle = ComboBoxStyle.DropDownList
        self.cb_coord.Location = Point(16, 274)
        self.cb_coord.Size = Size(360, 24)
        self.cb_coord.Items.Add(u"Internal Origin (gốc Revit)")
        self.cb_coord.Items.Add(u"Shared Coordinates (toạ độ chung)")
        self.cb_coord.SelectedIndex = 1 if self.settings.get("shared") else 0
        f.Controls.Add(self.cb_coord)

        f.Controls.Add(_label(u"Phân loại dầm (Structural Framing)", 16, 312, 360, bold=True))
        f.Controls.Add(_label(u"B dầm > (mm) là móng băng, còn lại là dầm móng", 16, 334, 360))
        self.tb_bang = TextBox()
        self.tb_bang.Location = Point(16, 358)
        self.tb_bang.Size = Size(90, 24)
        self.tb_bang.Text = u"%g" % float(self.settings.get("bang_b") or 800)
        f.Controls.Add(self.tb_bang)

        f.Controls.Add(_label(u"2. Family cọc (Generic Models / Structural Foundation / Structural Columns)", 400, 12, 480, bold=True))
        self.clb_fam = CheckedListBox()
        self.clb_fam.Location = Point(400, 36)
        self.clb_fam.Size = Size(470, 130)
        self.clb_fam.CheckOnClick = True
        self.clb_fam.BorderStyle = BorderStyle.FixedSingle
        saved = set(self.settings.get("families") or [])
        for fam in families:
            lab = (u"  [%s]" % fam[2]) if len(fam) > 2 else u""
            self.clb_fam.Items.Add(u"%s  (%d)%s" % (fam[0], fam[1], lab), fam[0] in saved)
        f.Controls.Add(self.clb_fam)
        self.clb_fam.SelectedIndexChanged += self._on_fam

        f.Controls.Add(_label(u"Đường kính / cạnh cọc", 400, 176, 150))
        self.cb_d = ComboBox()
        self.cb_d.DropDownStyle = ComboBoxStyle.DropDownList
        self.cb_d.Location = Point(400, 198)
        self.cb_d.Size = Size(150, 24)
        f.Controls.Add(self.cb_d)
        f.Controls.Add(_label(u"Chiều dài cọc", 560, 176, 150))
        self.cb_l = ComboBox()
        self.cb_l.DropDownStyle = ComboBoxStyle.DropDownList
        self.cb_l.Location = Point(560, 198)
        self.cb_l.Size = Size(150, 24)
        f.Controls.Add(self.cb_l)
        f.Controls.Add(_label(u"Hình dạng cọc", 720, 176, 150))
        self.cb_shape = ComboBox()
        self.cb_shape.DropDownStyle = ComboBoxStyle.DropDownList
        self.cb_shape.Location = Point(720, 198)
        self.cb_shape.Size = Size(150, 24)
        self.cb_shape.Items.Add(u"Tròn")
        self.cb_shape.Items.Add(u"Vuông")
        self.cb_shape.SelectedIndex = 1 if self.settings.get("shape") == u"Vuông" else 0
        f.Controls.Add(self.cb_shape)

        f.Controls.Add(_label(u"2b. Family là ĐÀI CỌC (Structural Foundation) - tick để luôn coi là đài, kể cả khi chưa tìm thấy cọc", 400, 236, 480, 36, bold=True))
        self.clb_dai = CheckedListBox()
        self.clb_dai.Location = Point(400, 276)
        self.clb_dai.Size = Size(470, 110)
        self.clb_dai.CheckOnClick = True
        self.clb_dai.BorderStyle = BorderStyle.FixedSingle
        dsaved = self.settings.get("dai_fams")
        dsaved = set(dsaved) if dsaved is not None else None
        for name, cnt in self.dai_families:
            self.clb_dai.Items.Add(u"%s  (%d)" % (name, cnt), (name in dsaved) if dsaved is not None else False)
        f.Controls.Add(self.clb_dai)

        f.Controls.Add(_label(u"Số hiệu móng / dầm / cột lấy theo Mark trong Revit (cùng Mark = cùng loại, nhập thép một lần).", 16, 402, 860))

        f.Controls.Add(_label(u"4. File Excel kết quả", 16, 436, 300, bold=True))
        self.tb_path = TextBox()
        self.tb_path.Location = Point(16, 460)
        self.tb_path.Size = Size(760, 24)
        self.tb_path.Text = default_path
        f.Controls.Add(self.tb_path)
        b_browse = _button(u"Chọn...", 786, 458, 84, 28)
        b_browse.Click += self._on_browse
        f.Controls.Add(b_browse)

        self.chk_dark = CheckBox()
        self.chk_dark.Text = u"Giao diện tối"
        self.chk_dark.Location = Point(16, 504)
        self.chk_dark.Size = Size(160, 24)
        self.chk_dark.Checked = dark
        self.chk_dark.CheckedChanged += self._on_theme
        f.Controls.Add(self.chk_dark)

        self.btn_ok = _button(u"Quét", 660, 610, 100, 34)
        self.btn_ok.Click += self._on_ok
        f.Controls.Add(self.btn_ok)
        self.btn_cancel = _button(u"Hủy", 770, 610, 100, 34)
        self.btn_cancel.Click += self._on_cancel
        f.Controls.Add(self.btn_cancel)
        f.AcceptButton = self.btn_ok
        f.CancelButton = self.btn_cancel
        apply_theme(f, DARK if dark else LIGHT)
        if self.clb_fam.Items.Count:
            self.clb_fam.SelectedIndex = 0

    def _on_theme(self, s, e):
        apply_theme(self.f, DARK if self.chk_dark.Checked else LIGHT)

    def _on_browse(self, s, e):
        dlg = SaveFileDialog()
        dlg.Filter = "Excel (*.xlsx)|*.xlsx"
        dlg.FileName = os.path.basename(self.tb_path.Text) or "Mong.xlsx"
        d = os.path.dirname(self.tb_path.Text)
        if d and os.path.isdir(d):
            dlg.InitialDirectory = d
        dlg.OverwritePrompt = False
        if dlg.ShowDialog() == DialogResult.OK:
            self.tb_path.Text = dlg.FileName

    def _fam_name(self, idx):
        return self.families[idx][0]

    @staticmethod
    def _plain(s):
        import unicodedata
        s = unicodedata.normalize("NFD", u"%s" % s)
        s = u"".join(ch for ch in s if unicodedata.category(ch) != "Mn")
        return s.replace(u"đ", u"d").replace(u"Đ", u"D").lower()

    def _on_fam(self, s, e):
        i = self.clb_fam.SelectedIndex
        if i < 0:
            return
        try:
            names = self.get_params(self._fam_name(i))
        except Exception:
            names = []
        plain = [self._plain(n) for n in names]
        for cb, key, hints in ((self.cb_d, "d_param", ("duong kinh", "dk", "diameter", "dia", "d", "canh", "size")),
                               (self.cb_l, "l_param", ("chieu dai", "dai", "length", "len", "l"))):
            cb.Items.Clear()
            cb.Items.Add(self.NONE_TXT)
            for n in names:
                cb.Items.Add(n)
            want = self.settings.get(key)
            idx = 0
            if want and want in names:
                idx = names.index(want) + 1
            else:
                for h in hints:           # khop chinh xac truoc, roi khop mot phan (khong dau)
                    for j, n in enumerate(plain):
                        if n == h:
                            idx = j + 1
                            break
                    if idx:
                        break
                if not idx:
                    for h in hints[:2] + hints[2:4]:
                        for j, n in enumerate(plain):
                            if len(h) > 2 and h in n:
                                idx = j + 1
                                break
                        if idx:
                            break
            cb.SelectedIndex = idx

    def _on_ok(self, s, e):
        lv = [i for i in range(self.clb_lv.Items.Count) if self.clb_lv.GetItemChecked(i)]
        if not lv:
            msg(u"Chọn ít nhất một Level.", icon=MessageBoxIcon.Warning)
            return
        path = self.tb_path.Text.strip()
        if not path:
            msg(u"Chọn nơi lưu file Excel.", icon=MessageBoxIcon.Warning)
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        fams = [self._fam_name(i) for i in range(self.clb_fam.Items.Count) if self.clb_fam.GetItemChecked(i)]
        dai = [self.dai_families[i][0] for i in range(self.clb_dai.Items.Count) if self.clb_dai.GetItemChecked(i)]
        d = self.cb_d.Text if self.cb_d.SelectedIndex > 0 else ""
        l = self.cb_l.Text if self.cb_l.SelectedIndex > 0 else ""
        try:
            bang_b = float(self.tb_bang.Text.replace(",", "."))
        except Exception:
            msg(u"B dầm không hợp lệ.", icon=MessageBoxIcon.Warning)
            return
        self.result = {"levels": lv, "path": path, "shared": self.cb_coord.SelectedIndex == 1, "bang_b": bang_b,
                       "dark": self.chk_dark.Checked,
                       "pile": {"families": fams, "d_param": d, "l_param": l, "shape": self.cb_shape.Text,
                                "dai_fams": dai}}
        self.f.DialogResult = DialogResult.OK
        self.f.Close()

    def _on_cancel(self, s, e):
        self.f.DialogResult = DialogResult.Cancel
        self.f.Close()

    def show(self):
        self.f.ShowDialog()
        return self.result


# ===================================================================== tao thep nhanh & chon dam
class QuickRebarDialog(object):
    def __init__(self, cfg, dark=True):
        self.cfg = dict(cfg or {})
        self.result = None
        f = Form()
        f.Text = u"Chế độ tạo thép móng nhanh (TCVN)"
        f.Size = Size(680, 560)
        f.StartPosition = FormStartPosition.CenterParent
        f.FormBorderStyle = FormBorderStyle.FixedDialog
        f.MaximizeBox = False
        f.MinimizeBox = False
        f.Font = Font(FONT, 9.0)
        self.f = f

        def add_num(lbl, x, y, key, default, w_lbl=155, w_box=64):
            f.Controls.Add(_label(lbl, x, y + 3, w_lbl, 20))
            tb = TextBox()
            tb.Location = Point(x + w_lbl, y)
            tb.Size = Size(w_box, 24)
            tb.Text = u"%g" % float(self.cfg.get(key, default))
            f.Controls.Add(tb)
            return tb

        def add_chk(lbl, x, y, key, default, w=210):
            cb = CheckBox()
            cb.Text = lbl
            cb.Location = Point(x, y)
            cb.Size = Size(w, 22)
            cb.Checked = bool(self.cfg.get(key, default))
            f.Controls.Add(cb)
            return cb

        y = 14
        f.Controls.Add(_label(u"1. Móng đơn & Đài cọc (mặc định d12a200)", 16, y, 420, bold=True))
        y += 26
        self.tb_don_d = add_num(u"Móng đơn Ø (mm):", 24, y, "don_d", 12, 130, 55)
        self.tb_don_a = add_num(u"a (mm):", 220, y, "don_a", 200, 60, 60)
        self.chk_don_top = add_chk(u"Có thép lớp trên", 360, y, "don_top", False, 180)
        y += 30
        self.tb_dai_d = add_num(u"Đài cọc Ø (mm):", 24, y, "dai_d", 12, 130, 55)
        self.tb_dai_a = add_num(u"a (mm):", 220, y, "dai_a", 200, 60, 60)
        self.chk_dai_top = add_chk(u"Đài 4 mặt (trên+đai thành)", 360, y, "dai_top", True, 240)

        y += 42
        f.Controls.Add(_label(u"2. Móng băng & Dầm móng", 16, y, 420, bold=True))
        y += 26
        self.tb_top_n = add_num(u"Lớp trên (số thanh):", 24, y, "top_n", 3, 140, 50)
        self.tb_top_d = add_num(u"Ø (mm):", 220, y, "top_d", 18, 60, 50)
        self.chk_top_tc = add_chk(u"Tăng cường trên:", 340, y, "top_tc_on", True, 145)
        self.tb_top_tc_n = add_num(u"", 488, y, "top_tc_n", 2, 0, 42)
        self.tb_top_tc_d = add_num(u"Ø", 538, y, "top_tc_d", 18, 22, 48)
        y += 30
        self.tb_bot_n = add_num(u"Lớp dưới (số thanh):", 24, y, "bot_n", 3, 140, 50)
        self.tb_bot_d = add_num(u"Ø (mm):", 220, y, "bot_d", 18, 60, 50)
        self.chk_bot_tc = add_chk(u"Tăng cường dưới:", 340, y, "bot_tc_on", True, 145)
        self.tb_bot_tc_n = add_num(u"", 488, y, "bot_tc_n", 2, 0, 42)
        self.tb_bot_tc_d = add_num(u"Ø", 538, y, "bot_tc_d", 18, 22, 48)
        y += 32
        self.tb_stir_d = add_num(u"Thép đai Ø (mm):", 24, y, "stir_d", 8, 140, 50)
        self.tb_stir_a1 = add_num(u"a gối:", 220, y, "stir_a1", 100, 50, 55)
        self.tb_stir_a2 = add_num(u"a nhịp:", 340, y, "stir_a2", 200, 55, 55)
        y += 30
        self.chk_stir_tc = add_chk(u"Đai tăng cường:", 24, y, "stir_tc_on", True, 145)
        self.tb_stir_tc_d = add_num(u"Ø", 174, y, "stir_tc_d", 8, 22, 46)
        self.tb_stir_tc_a = add_num(u"a:", 254, y, "stir_tc_a", 500, 25, 55)
        self.chk_skin = add_chk(u"Chống phình:", 350, y, "skin_on", True, 115)
        self.tb_skin_n = add_num(u"", 468, y, "skin_n", 2, 0, 42)
        self.tb_skin_d = add_num(u"Ø", 518, y, "skin_d", 12, 22, 48)
        y += 32
        self.chk_wing = add_chk(u"Thép cánh móng băng:", 24, y, "wing_on", True, 175)
        self.tb_wing_d = add_num(u"Ø", 210, y, "wing_d", 12, 22, 50)
        self.tb_wing_a = add_num(u"a:", 292, y, "wing_a", 200, 25, 55)

        y += 42
        f.Controls.Add(_label(u"3. Phạm vi áp dụng", 16, y, 300, bold=True))
        y += 24
        self.cb_scope = ComboBox()
        self.cb_scope.DropDownStyle = ComboBoxStyle.DropDownList
        self.cb_scope.Location = Point(24, y)
        self.cb_scope.Size = Size(420, 24)
        self.cb_scope.Items.Add(u"Tất cả các cấu kiện (ghi đè thép cũ)")
        self.cb_scope.Items.Add(u"Chỉ tạo cho các cấu kiện chưa có thép")
        self.cb_scope.Items.Add(u"Chỉ áp dụng cho Móng đơn")
        self.cb_scope.Items.Add(u"Chỉ áp dụng cho Đài cọc")
        self.cb_scope.Items.Add(u"Chỉ áp dụng cho Móng băng")
        self.cb_scope.Items.Add(u"Chỉ áp dụng cho Dầm móng")
        self.cb_scope.SelectedIndex = 0
        f.Controls.Add(self.cb_scope)

        btn_ok = _button(u"Áp dụng tạo nhanh", 400, 472, 150, 34)
        btn_ok.Click += self._on_ok
        btn_cancel = _button(u"Hủy", 560, 472, 92, 34)
        btn_cancel.Click += self._on_cancel
        f.Controls.Add(btn_ok)
        f.Controls.Add(btn_cancel)
        f.AcceptButton = btn_ok
        f.CancelButton = btn_cancel
        apply_theme(f, DARK if dark else LIGHT)

    def _num(self, tb, default):
        try:
            return float(tb.Text.replace(",", "."))
        except Exception:
            return default

    def _on_ok(self, s, e):
        cfg = {
            "don_d": self._num(self.tb_don_d, 12.0), "don_a": self._num(self.tb_don_a, 200.0),
            "don_top": self.chk_don_top.Checked,
            "dai_d": self._num(self.tb_dai_d, 12.0), "dai_a": self._num(self.tb_dai_a, 200.0),
            "dai_top": self.chk_dai_top.Checked, "dai_side_on": self.chk_dai_top.Checked,
            "top_n": int(self._num(self.tb_top_n, 3)), "top_d": self._num(self.tb_top_d, 18.0),
            "top_tc_on": self.chk_top_tc.Checked,
            "top_tc_n": int(self._num(self.tb_top_tc_n, 2)), "top_tc_d": self._num(self.tb_top_tc_d, 18.0),
            "bot_n": int(self._num(self.tb_bot_n, 3)), "bot_d": self._num(self.tb_bot_d, 18.0),
            "bot_tc_on": self.chk_bot_tc.Checked,
            "bot_tc_n": int(self._num(self.tb_bot_tc_n, 2)), "bot_tc_d": self._num(self.tb_bot_tc_d, 18.0),
            "stir_d": self._num(self.tb_stir_d, 8.0), "stir_a1": self._num(self.tb_stir_a1, 100.0),
            "stir_a2": self._num(self.tb_stir_a2, 200.0),
            "stir_tc_on": self.chk_stir_tc.Checked,
            "stir_tc_d": self._num(self.tb_stir_tc_d, 8.0), "stir_tc_a": self._num(self.tb_stir_tc_a, 500.0),
            "skin_on": self.chk_skin.Checked,
            "skin_n": int(self._num(self.tb_skin_n, 2)), "skin_d": self._num(self.tb_skin_d, 12.0),
            "wing_on": self.chk_wing.Checked,
            "wing_d": self._num(self.tb_wing_d, 12.0), "wing_a": self._num(self.tb_wing_a, 200.0),
        }
        self.result = {"cfg": cfg, "scope": self.cb_scope.SelectedIndex}
        self.f.DialogResult = DialogResult.OK
        self.f.Close()

    def _on_cancel(self, s, e):
        self.f.DialogResult = DialogResult.Cancel
        self.f.Close()

    def show(self):
        self.f.ShowDialog()
        return self.result


class BeamReinforceDialog(object):
    """Chon tung dam / mong bang de ap dung che do tang cuong rieng re."""
    def __init__(self, beam_items, modes, cfg, dark=True):
        self.beam_items = beam_items       # list[(loai, ten, desc)]
        self.modes = modes                 # list[(code, label)]
        self.cfg = dict(cfg or {})
        self.result = None
        f = Form()
        f.Text = u"Chọn dầm móng / móng băng — Chế độ tăng cường riêng"
        f.Size = Size(700, 540)
        f.StartPosition = FormStartPosition.CenterParent
        f.FormBorderStyle = FormBorderStyle.FixedDialog
        f.MaximizeBox = False
        f.MinimizeBox = False
        f.Font = Font(FONT, 9.0)
        self.f = f

        f.Controls.Add(_label(u"1. Tick chọn các dầm móng / móng băng cần gán chế độ tăng cường:", 16, 12, 500, bold=True))
        self.clb = CheckedListBox()
        self.clb.Location = Point(16, 36)
        self.clb.Size = Size(650, 220)
        self.clb.CheckOnClick = True
        self.clb.BorderStyle = BorderStyle.FixedSingle
        for loai, ten, desc in beam_items:
            self.clb.Items.Add(desc, False)
        f.Controls.Add(self.clb)

        b_all = _button(u"Chọn tất cả", 16, 262, 100, 26)
        b_none = _button(u"Bỏ chọn", 122, 262, 90, 26)
        b_all.Click += lambda s, e: [self.clb.SetItemChecked(i, True) for i in range(self.clb.Items.Count)]
        b_none.Click += lambda s, e: [self.clb.SetItemChecked(i, False) for i in range(self.clb.Items.Count)]
        f.Controls.Add(b_all)
        f.Controls.Add(b_none)

        f.Controls.Add(_label(u"2. Chọn chế độ tăng cường áp dụng cho các dầm đã tick:", 16, 300, 480, bold=True))
        self.cb_mode = ComboBox()
        self.cb_mode.DropDownStyle = ComboBoxStyle.DropDownList
        self.cb_mode.Location = Point(16, 324)
        self.cb_mode.Size = Size(360, 24)
        for _, lab in modes:
            self.cb_mode.Items.Add(lab)
        self.cb_mode.Items.Add(u"Tùy chỉnh thông số tăng cường riêng...")
        self.cb_mode.SelectedIndex = 0
        f.Controls.Add(self.cb_mode)

        f.Controls.Add(_label(u"Tùy chỉnh nhanh số thanh & Ø (áp dụng khi tạo cho các dầm đã chọn):", 16, 360, 560))
        self.tb_top_tc_n = self._num_box(f, u"TC trên nhịp:", 16, 386, self.cfg.get("top_tc_n", 2), 110, 48)
        self.tb_top_tc_d = self._num_box(f, u"Ø:", 184, 386, self.cfg.get("top_tc_d", 18), 24, 48)
        self.tb_bot_tc_n = self._num_box(f, u"TC dưới gối:", 270, 386, self.cfg.get("bot_tc_n", 2), 110, 48)
        self.tb_bot_tc_d = self._num_box(f, u"Ø:", 438, 386, self.cfg.get("bot_tc_d", 18), 24, 48)
        self.chk_stir_tc = CheckBox()
        self.chk_stir_tc.Text = u"Đai tăng cường d8a500"
        self.chk_stir_tc.Location = Point(16, 420)
        self.chk_stir_tc.Size = Size(200, 22)
        self.chk_stir_tc.Checked = bool(self.cfg.get("stir_tc_on", True))
        f.Controls.Add(self.chk_stir_tc)
        self.chk_skin = CheckBox()
        self.chk_skin.Text = u"Thép chống phình 2d12"
        self.chk_skin.Location = Point(230, 420)
        self.chk_skin.Size = Size(210, 22)
        self.chk_skin.Checked = bool(self.cfg.get("skin_on", True))
        f.Controls.Add(self.chk_skin)

        btn_ok = _button(u"Áp dụng cho dầm đã chọn", 370, 456, 190, 34)
        btn_ok.Click += self._on_ok
        btn_cancel = _button(u"Đóng", 570, 456, 96, 34)
        btn_cancel.Click += self._on_cancel
        f.Controls.Add(btn_ok)
        f.Controls.Add(btn_cancel)
        apply_theme(f, DARK if dark else LIGHT)

    def _num_box(self, f, lbl, x, y, val, wl, wb):
        f.Controls.Add(_label(lbl, x, y + 3, wl, 20))
        tb = TextBox()
        tb.Location = Point(x + wl, y)
        tb.Size = Size(wb, 24)
        tb.Text = u"%g" % float(val)
        f.Controls.Add(tb)
        return tb

    def _num(self, tb, d):
        try:
            return float(tb.Text.replace(",", "."))
        except Exception:
            return d

    def _on_ok(self, s, e):
        sel = [(self.beam_items[i][0], self.beam_items[i][1]) for i in range(self.clb.Items.Count) if self.clb.GetItemChecked(i)]
        if not sel:
            msg(u"Hãy tick chọn ít nhất một dầm / móng băng.", icon=MessageBoxIcon.Warning)
            return
        idx = self.cb_mode.SelectedIndex
        mode = self.modes[idx][0] if idx < len(self.modes) else "custom"
        cfg = dict(self.cfg)
        cfg["top_tc_n"] = int(self._num(self.tb_top_tc_n, 2))
        cfg["top_tc_d"] = self._num(self.tb_top_tc_d, 18.0)
        cfg["bot_tc_n"] = int(self._num(self.tb_bot_tc_n, 2))
        cfg["bot_tc_d"] = self._num(self.tb_bot_tc_d, 18.0)
        cfg["stir_tc_on"] = self.chk_stir_tc.Checked
        cfg["skin_on"] = self.chk_skin.Checked
        if mode == "custom":
            cfg["top_tc_on"] = cfg["top_tc_n"] > 0
            cfg["bot_tc_on"] = cfg["bot_tc_n"] > 0
        self.result = {"items": sel, "mode": mode, "cfg": cfg}
        self.f.DialogResult = DialogResult.OK
        self.f.Close()

    def _on_cancel(self, s, e):
        self.f.DialogResult = DialogResult.Cancel
        self.f.Close()

    def show(self):
        self.f.ShowDialog()
        return self.result
