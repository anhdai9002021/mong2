# -*- coding: utf-8 -*-
"""Hinh hoc 2D thuan Python (mm). Khong phu thuoc Revit nen test duoc rieng."""
import math


def dedupe(poly, eps=0.5):
    out = []
    for p in poly:
        if not out or abs(p[0] - out[-1][0]) > eps or abs(p[1] - out[-1][1]) > eps:
            out.append((p[0], p[1]))
    if len(out) > 1 and abs(out[0][0] - out[-1][0]) <= eps and abs(out[0][1] - out[-1][1]) <= eps:
        out.pop()
    return out


def drop_collinear(poly, eps=1e-4):
    n = len(poly)
    if n < 4:
        return list(poly)
    out = []
    for i in range(n):
        a = poly[i - 1]
        b = poly[i]
        c = poly[(i + 1) % n]
        ux, uy = b[0] - a[0], b[1] - a[1]
        vx, vy = c[0] - b[0], c[1] - b[1]
        la = math.hypot(ux, uy)
        lc = math.hypot(vx, vy)
        if la < 1e-9 or lc < 1e-9:
            continue
        cross = ux * vy - uy * vx
        dot = ux * vx + uy * vy
        if abs(cross) / (la * lc) < eps and dot > 0:
            continue
        out.append(b)
    return out


def signed_area(poly):
    s = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return s / 2.0


def area(poly):
    return abs(signed_area(poly))


def ensure_ccw(poly):
    return list(poly) if signed_area(poly) >= 0 else list(reversed(poly))


def clean_polygon(poly):
    p = dedupe(poly)
    p = drop_collinear(p)
    p = dedupe(p)
    if len(p) >= 3:
        p = ensure_ccw(p)
    return p


def centroid(poly):
    a = signed_area(poly)
    if abs(a) < 1e-9:
        n = float(len(poly)) or 1.0
        return (sum(p[0] for p in poly) / n, sum(p[1] for p in poly) / n)
    cx = cy = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        f = x1 * y2 - x2 * y1
        cx += (x1 + x2) * f
        cy += (y1 + y2) * f
    return (cx / (6.0 * a), cy / (6.0 * a))


def bbox(poly):
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    return (min(xs), min(ys), max(xs), max(ys))


def _pt_seg(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    l2 = dx * dx + dy * dy
    if l2 < 1e-12:
        return math.hypot(p[0] - a[0], p[1] - a[1])
    t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2
    t = max(0.0, min(1.0, t))
    return math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy))


def point_in_poly(pt, poly, eps=0.0):
    if len(poly) < 3:
        return False
    if eps > 0:
        n = len(poly)
        for i in range(n):
            if _pt_seg(pt, poly[i], poly[(i + 1) % n]) <= eps:
                return True
    x, y = pt
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y):
            xin = (xj - xi) * (y - yi) / (yj - yi) + xi
            if x < xin:
                inside = not inside
        j = i
    return inside


def _extents(poly, th_deg):
    c = math.cos(math.radians(th_deg))
    s = math.sin(math.radians(th_deg))
    us = [p[0] * c + p[1] * s for p in poly]
    vs = [-p[0] * s + p[1] * c for p in poly]
    return (max(us) - min(us), max(vs) - min(vs), min(us), max(us), min(vs), max(vs), c, s)


def min_area_rect(poly):
    """Hop bao nho nhat. Tra ve (goc_do [0,90), cd_u, cd_v, cx, cy)."""
    best = None
    seen = set()
    n = len(poly)
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        dx, dy = b[0] - a[0], b[1] - a[1]
        if math.hypot(dx, dy) < 1e-9:
            continue
        th = math.degrees(math.atan2(dy, dx)) % 90.0
        if th > 89.999 or th < 0.001:
            th = 0.0
        key = round(th, 3)
        if key in seen:
            continue
        seen.add(key)
        e = _extents(poly, th)
        ar = e[0] * e[1]
        if best is None or ar < best[0] - 1e-6:
            best = (ar, th, e)
    if best is None:
        x0, y0, x1, y1 = bbox(poly)
        return (0.0, x1 - x0, y1 - y0, (x0 + x1) / 2.0, (y0 + y1) / 2.0)
    th, e = best[1], best[2]
    cu = (e[2] + e[3]) / 2.0
    cv = (e[4] + e[5]) / 2.0
    c, s = e[6], e[7]
    return (th, e[0], e[1], cu * c - cv * s, cu * s + cv * c)


def _orient(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def _seg_intersect(a, b, c, d):
    d1 = _orient(c, d, a)
    d2 = _orient(c, d, b)
    d3 = _orient(a, b, c)
    d4 = _orient(a, b, d)
    return ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0)) and d1 * d2 < 0 and d3 * d4 < 0


def seg_dist(a, b, c, d):
    if _seg_intersect(a, b, c, d):
        return 0.0
    return min(_pt_seg(a, c, d), _pt_seg(b, c, d), _pt_seg(c, a, b), _pt_seg(d, a, b))


def strip_params(poly, p0, p1):
    """Thong so doan mong bang theo duong tim p0->p1.
    Tra ve dict: len (dai tim), b (be rong), offset (lech tam, + ve ben trai), ext_len."""
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    L = math.hypot(dx, dy)
    if L < 1e-6:
        return None
    ux, uy = dx / L, dy / L
    nx, ny = -uy, ux
    us = [(p[0] - p0[0]) * ux + (p[1] - p0[1]) * uy for p in poly]
    vs = [(p[0] - p0[0]) * nx + (p[1] - p0[1]) * ny for p in poly]
    return {"len": L, "b": max(vs) - min(vs), "offset": (max(vs) + min(vs)) / 2.0,
            "ext_len": max(us) - min(us)}


def group_segments(items, tol=20.0):
    """items: list[dict(p0, p1, reach)]. Tra ve list chi so nhom (0..k-1) cho tung item."""
    n = len(items)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(n):
        for j in range(i + 1, n):
            d = seg_dist(items[i]["p0"], items[i]["p1"], items[j]["p0"], items[j]["p1"])
            if d <= items[i]["reach"] + items[j]["reach"] + tol:
                ri, rj = find(i), find(j)
                if ri != rj:
                    parent[rj] = ri
    labels = {}
    out = []
    for i in range(n):
        r = find(i)
        if r not in labels:
            labels[r] = len(labels)
        out.append(labels[r])
    return out


def offset_polygon(poly, d):
    """Mo rong da giac ra ngoai d mm (noi giao cac canh dich ra, kieu mitre). Dung ve be tong lot."""
    pts = ensure_ccw(list(poly))
    n = len(pts)
    if n < 3 or abs(d) < 1e-9:
        return list(pts)
    lines = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = math.hypot(dx, dy)
        if L < 1e-9:
            continue
        nx, ny = dy / L, -dx / L          # phap tuyen phai = huong ra ngoai voi da giac nguoc kim dong ho
        lines.append(((a[0] + nx * d, a[1] + ny * d), (dx, dy)))
    out = []
    m = len(lines)
    for i in range(m):
        p, u = lines[i - 1]
        q, v = lines[i]
        den = u[0] * v[1] - u[1] * v[0]
        if abs(den) < 1e-9 * math.hypot(*u) * math.hypot(*v):
            out.append(q)
        else:
            t = ((q[0] - p[0]) * v[1] - (q[1] - p[1]) * v[0]) / den
            out.append((p[0] + u[0] * t, p[1] + u[1] * t))
    return out


def clip_intervals(poly, axis, c):
    """axis 'u': duong chay doc u tai v=c; axis 'v': chay doc v tai u=c. Tra ve cac doan nam trong poly."""
    pts = poly if axis == "u" else [(p[1], p[0]) for p in poly]
    c = c + 1e-6
    xs = []
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        if (y1 > c) != (y2 > c):
            xs.append(x1 + (c - y1) * (x2 - x1) / (y2 - y1))
    xs.sort()
    return [(xs[i], xs[i + 1]) for i in range(0, len(xs) - 1, 2)]
